package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * This class establishes a connection to the database.
 * @author srw565
 */
public class ConnectionManager {

    static Connection con;
    static String url;

    /**
     * This method establishes the connection to the database
     * @return the connection
     */
    public static Connection getConnection() {

        String url = "jdbc:mysql://papyrus.usask.ca/cmpt370group07";
        String dbname = "cmpt370group07";
        String usernm = "cmpt370group07";
        String passwd = "351j1len";

        try {

            Class.forName("com.mysql.jdbc.Driver");

            try {
                con = DriverManager.getConnection(url, usernm, passwd);

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            System.out.println(e);
        }

        return con;
    }
}
