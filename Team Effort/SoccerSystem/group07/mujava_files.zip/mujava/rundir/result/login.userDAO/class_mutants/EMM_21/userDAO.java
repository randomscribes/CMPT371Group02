// This is mutant program.
// Author : ysma

package login;


import Connection.ConnectionManager;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Date;


public class userDAO
{

    static java.sql.Connection currentCon = null;

    static java.sql.ResultSet rs = null;

    public static login.userBean login( login.userBean bean )
    {
        java.sql.Statement stmt = null;
        java.lang.String username = bean.getUsername();
        java.lang.String password = bean.getPassword();
        java.lang.String searchQuery = "select * from users where username='" + username + "' AND password='" + password + "'";
        System.out.println( "Your user name is " + username );
        System.out.println( "Your password is " + password );
        System.out.println( "Query: " + searchQuery );
        try {
            currentCon = ConnectionManager.getConnection();
            stmt = currentCon.createStatement();
            rs = stmt.executeQuery( searchQuery );
            boolean more = rs.next();
            if (!more) {
                System.out.println( "Sorry, you are not a registered user! Please sign up first" );
                bean.setValid( false );
            } else {
                if (more) {
                    java.lang.Integer user_id = rs.getInt( "user_id" );
                    java.lang.String firstName = rs.getString( "first_name" );
                    java.lang.String lastName = rs.getString( "last_name" );
                    java.lang.String address = rs.getString( "address" );
                    java.lang.Integer team_id = rs.getInt( "team_id" );
                    java.util.Date birthdate = rs.getDate( "birthdate" );
                    java.lang.Integer phone_number = rs.getInt( "phone_number" );
                    short fees_paid = rs.getShort( "fees_paid" );
                    java.lang.Integer jersey_number = rs.getInt( "jersey_number" );
                    java.lang.Integer accessLevel = rs.getInt( "access" );
                    System.out.println( "Welcome " + firstName );
                    bean.setUser_id( user_id );
                    bean.setFirstName( firstName );
                    bean.setLastName( lastName );
                    bean.setAccessLevel( accessLevel );
                    bean.setAddress( address );
                    bean.setBirthdate( birthdate );
                    bean.setFees_paid( fees_paid );
                    bean.setUser_id( jersey_number );
                    bean.setPhone_number( phone_number );
                    bean.setTeam_id( team_id );
                    bean.setValid( true );
                }
            }
        } catch ( java.lang.Exception ex ) {
            System.out.println( "Log In failed: An Exception has occurred! " + ex );
        } finally 
{
            if (rs != null) {
                try {
                    rs.close();
                } catch ( java.lang.Exception e ) {
                }
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch ( java.lang.Exception e ) {
                }
                stmt = null;
            }
            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch ( java.lang.Exception e ) {
                }
                currentCon = null;
            }
        }
        return bean;
    }

}
