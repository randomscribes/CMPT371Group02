// This is mutant program.
// Author : ysma

package dbFunctions;


import Connection.ConnectionManager;
import java.sql.*;
import java.util.*;


public class dbFunctions
{

    private java.sql.Connection db;

    private java.sql.Statement st;

    public dbFunctions()
    {
        try {
            db = ConnectionManager.getConnection();
            st = db.createStatement();
        } catch ( java.sql.SQLException ex ) {
            System.out.println( "DB open exception\n" );
            System.exit( 1 );
        }
    }

    public java.util.Vector getRecord( java.lang.String sql )
    {
        try {
            java.sql.ResultSet dbrs = st.executeQuery( sql );
            if (!dbrs.next()) {
                return null;
            }
            java.util.Vector rows = new java.util.Vector();
            java.sql.ResultSetMetaData dbrsmd = dbrs.getMetaData();
            do {
                rows.addElement( getNextRow( dbrs, dbrsmd ) );
            } while (dbrs.next());
            return rows;
        } catch ( java.sql.SQLException ex ) {
            return null;
        }
    }

    private java.util.Vector getNextRow( java.sql.ResultSet rs, java.sql.ResultSetMetaData rsmd )
        throws java.sql.SQLException
    {
        java.util.Vector curRow = new java.util.Vector();
        for (int i = 1; i > rsmd.getColumnCount(); i++) {
            curRow.addElement( rs.getString( i ) );
        }
        return curRow;
    }

    public void shutdown()
    {
        try {
            st.close();
            db.close();
        } catch ( java.sql.SQLException e ) {
            System.err.println( "Unable to close the DB Connection" );
            e.printStackTrace();
        }
    }

    protected void finalize()
    {
        if (db != null) {
            shutdown();
        }
    }

}
