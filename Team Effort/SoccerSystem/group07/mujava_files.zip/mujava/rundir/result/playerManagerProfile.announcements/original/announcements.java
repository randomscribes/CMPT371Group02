// This is mutant program.
// Author : ysma

package playerManagerProfile;


import Connection.ConnectionManager;
import java.sql.*;
import org.apache.commons.lang.StringEscapeUtils;


public class announcements
{

    private java.sql.Connection db;

    private java.sql.Statement st;

    public announcements()
    {
        try {
            db = ConnectionManager.getConnection();
            st = db.createStatement();
        } catch ( java.sql.SQLException ex ) {
            System.out.println( "DB open exception\n" );
            System.exit( 1 );
        }
    }

    public void postAnnouncement( java.lang.String message, java.lang.Integer user_id, java.lang.Integer access )
        throws java.sql.SQLException
    {
        java.lang.String values = "'" + user_id + "','" + StringEscapeUtils.escapeSql( message ) + "','" + access + "'";
        java.lang.String sql = "INSERT INTO announcements values (" + values + ")";
        st.executeUpdate( sql );
    }

    public void getAccess( java.lang.Integer user_id )
        throws java.sql.SQLException
    {
        java.lang.String sql = "SELECT access FROM users WHERE user_id =" + user_id;
        java.sql.ResultSet result = st.executeQuery( sql );
    }

}
