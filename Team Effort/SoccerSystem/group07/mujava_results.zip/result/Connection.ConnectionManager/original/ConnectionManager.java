// This is mutant program.
// Author : ysma

package Connection;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionManager
{

    static java.sql.Connection con;

    static java.lang.String url;

    public static java.sql.Connection getConnection()
    {
        java.lang.String url = "jdbc:mysql://edjo.usask.ca/cmpt371group2_TeamEffort";
        java.lang.String dbname = "cmpt371group2_TeamEffort";
        java.lang.String usernm = "cmpt371gr2user";
        java.lang.String passwd = "T33m3ff0rT";
        try {
            Class.forName( "com.mysql.jdbc.Driver" );
            try {
                con = DriverManager.getConnection( url, usernm, passwd );
            } catch ( java.sql.SQLException ex ) {
                ex.printStackTrace();
            }
        } catch ( java.lang.ClassNotFoundException e ) {
            System.out.println( e );
        }
        return con;
    }

}
