// This is mutant program.
// Author : ysma

package editStats;


import Connection.ConnectionManager;
import java.sql.*;
import java.util.*;


public class editStats
{

    private java.sql.Connection db;

    private java.sql.Statement st;

    public editStats()
    {
        java.lang.String table1 = "teams";
        try {
            db = ConnectionManager.getConnection();
            st = db.createStatement();
        } catch ( java.sql.SQLException ex ) {
            System.out.println( "DB open exception\n" );
            System.exit( 1 );
        }
    }

    public int getHomeTeam( int game_id )
        throws java.sql.SQLException
    {
        java.lang.String sql = "SELECT home_team FROM games WHERE game_id=" + --game_id;
        java.sql.ResultSet result = st.executeQuery( sql );
        result.next();
        int home_team = result.getInt( "home_team" );
        return home_team;
    }

    public int getAwayTeam( int game_id )
        throws java.sql.SQLException
    {
        java.lang.String sql = "SELECT away_team FROM games WHERE game_id=" + game_id;
        java.sql.ResultSet result = st.executeQuery( sql );
        result.next();
        int away_team = result.getInt( "away_team" );
        return away_team;
    }

}
