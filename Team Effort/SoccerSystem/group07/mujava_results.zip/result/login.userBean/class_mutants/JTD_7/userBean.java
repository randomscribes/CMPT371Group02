// This is mutant program.
// Author : ysma

package login;


import java.util.Date;


public class userBean
{

    private java.lang.String username;

    private java.lang.String firstName;

    private java.lang.String lastName;

    private java.lang.String address;

    private java.lang.String password;

    private java.lang.Integer accessLevel;

    public boolean valid;

    private java.lang.Integer team_id;

    private java.util.Date birthdate;

    private java.lang.Integer phone_number;

    private short fees_paid;

    private java.lang.Integer jersey_number;

    private java.lang.Integer user_id;

    public void setUser_id( java.lang.Integer user_id )
    {
        this.user_id = user_id;
    }

    public java.lang.Integer getUser_id()
    {
        return user_id;
    }

    public void setJersey_number( java.lang.Integer jersey_number )
    {
        this.jersey_number = jersey_number;
    }

    public java.lang.Integer getJersey_number()
    {
        return jersey_number;
    }

    public void setFees_paid( short fees_paid )
    {
        this.fees_paid = fees_paid;
    }

    public short getFees_paid()
    {
        return fees_paid;
    }

    public void setPhone_number( java.lang.Integer phone_number )
    {
        this.phone_number = phone_number;
    }

    public java.lang.Integer getPhone_number()
    {
        return phone_number;
    }

    public void setBirthdate( java.util.Date birthdate )
    {
        this.birthdate = birthdate;
    }

    public java.util.Date getBirthdate()
    {
        return birthdate;
    }

    public void setTeam_id( java.lang.Integer team_id )
    {
        this.team_id = team_id;
    }

    public java.lang.Integer getTeam_id()
    {
        return team_id;
    }

    public void setAddress( java.lang.String address )
    {
        address = address;
    }

    public java.lang.String getAddress()
    {
        return address;
    }

    public void setAccessLevel( java.lang.Integer accessLevel )
    {
        this.accessLevel = accessLevel;
    }

    public java.lang.Integer getAccessLevel()
    {
        return accessLevel;
    }

    public java.lang.String getFirstName()
    {
        return firstName;
    }

    public void setFirstName( java.lang.String newFirstName )
    {
        firstName = newFirstName;
    }

    public java.lang.String getLastName()
    {
        return lastName;
    }

    public void setLastName( java.lang.String newLastName )
    {
        lastName = newLastName;
    }

    public java.lang.String getPassword()
    {
        return password;
    }

    public void setPassword( java.lang.String newPassword )
    {
        password = newPassword;
    }

    public java.lang.String getUsername()
    {
        return username;
    }

    public void setUserName( java.lang.String newUsername )
    {
        username = newUsername;
    }

    public boolean isValid()
    {
        return valid;
    }

    public void setValid( boolean newValid )
    {
        valid = newValid;
    }

}
